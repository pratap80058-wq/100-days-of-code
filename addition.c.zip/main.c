/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
    float a,b,c , sum;
    printf("enter three number: ");
    scanf("%f %f %f", &a, &b,&c);//data read karta h
    
    sum = a+ b+c;
    printf("%.2f + %.2f + %.2f= %.2f\n ", a , b ,c, sum);
    return 0;
}
